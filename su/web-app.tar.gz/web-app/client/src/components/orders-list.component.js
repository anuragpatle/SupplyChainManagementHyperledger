import React, { Component } from 'react'

export class OrdersListComponent extends Component {
  render() {
    return (
      <div>
        Orders list component
      </div>
    )
  }
}

export default OrdersListComponent
