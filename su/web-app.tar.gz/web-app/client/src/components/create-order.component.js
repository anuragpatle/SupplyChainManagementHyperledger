import React, { Component } from 'react'

export class CreateOrder extends Component {
  render() {
    return (
      <div>
        Create order component
      </div>
    )
  }
}

export default CreateOrder
